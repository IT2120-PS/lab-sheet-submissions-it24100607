setwd("C:\\Users\\it24100607\\Desktop\\IT24100607")
getwd()
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
str(branch_data)
boxplot(branch_data$Sales, main = "Boxplot of Sales", ylab = "Sales", outline = TRUE, horizontal = TRUE)
advertising_summery <- summary(branch_data$Advertising)
print(advertising_summery)
advertising_iqr <- IQR(branch_data$Advertising)
print(paste("IQR for Advertising:", advertising_iqr))
find_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  
  outliers <- x[x < lower_bound | x > upper_bound]
  
  if(length(outliers) == 0) {
    return("No outliers detected")
  } else {
    return(sort(outliers))
  }
}

years_outliers <- find_outliers(branch_data$Years)
print(paste("Outliers in Years variable:", paste(years_outliers, collapse=", ")))
